
const configval=require('./config');
const apiRouter=require('./api');
const express=require('express');
const server=express();
const path=require('path');
const bodyparser=require('body-parser');
const MainPage=require('./api/Main');
const Merchant=require('./api/Merchant');
const Cust=require('./api/Customer');
// import  'config.js';
server.use(express.static(__dirname +'/public'));

server.get('/favicon.ico',(req,res,next)=>{
    return res.sendStatus(204);
});
server.set('view engine','pug');
server.locals.pretty=true;
server.use(bodyparser.json());
server.use(bodyparser.urlencoded({extended:true}));
const mainPage=new MainPage();
const merchant=new Merchant();
const customer=new Cust();
console.log('server1 ',server.get(__dirname));
server.set('views',path.join(__dirname,'./views'));
console.log('server ',server.get(__dirname));
//Initial page call
server.get('/',(req,res)=>{
  return  res.render('login');
});
//Login call
var LoginDetails;
server.post('/getId',function(req,res)
{
  console.log(req.body.username+' '+req.body.pwd+'formaction');
  var status;

  mainPage.getId(req.body.username,req.body.pwd,function (err, result){ 
    if(result.length==0) return res.redirect('/');
    console.log('here'+JSON.stringify(result));
    var string=JSON.stringify(result);
    LoginDetails=JSON.parse(string);
    status=true;
    console.log(LoginDetails[0].user_id+' '+LoginDetails[0].user_type);
    if(status===true)
  {
    server.locals.id=LoginDetails[0].user_id;
    server.locals.storename=LoginDetails[0].merchant_sname;
    if(LoginDetails[0].user_type==='M')
    {
      console.log('here1');
        return res.redirect('/Merchant');
    }
    else if(LoginDetails[0].user_type==='C')
    {
      console.log('here2');
        return res.redirect('/CustomerHome');
    }
  }
  });    
});
server.post('/RegisterPage',function(req,res)
{
  console.log('RegisterPage');
  return res.redirect('/Register');
});
server.get('/Register',(req,res)=>{
  return  res.render('Register');
});
server.post('/registersubmit',(req,res)=>{
  console.log(req.body);
  const val=mainPage.insertRegDetails(req.body);
  console.log(val);
  return res.redirect('/');
});
server.post('/Back',(req,res)=>{
  return res.redirect('/');
});
server.get('/Merchant',(req,res)=>{
  console.log('inside merchant'+server.locals.id);
  merchant.getMerchantCoupon(server.locals.id,function (err, result){ 
    if(result.length==0) return res.redirect('/Merchant');
    server.locals.merchantcoupons=JSON.parse(JSON.stringify(result));
    return  res.render('Merchant');
  });    
  
});
server.get('/MerchcustomerEntry',(req,res)=>{
  return  res.render('Merchcustentry');
});
server.get('/MerchcouponEntry',(req,res)=>{
  return  res.render('MerchcouponEntry');
});
server.get('/Logout',(req,res)=>{
  return  res.render('login');
});
server.get('/MerchantPersonalDetails',(req,res)=>{
  return  res.render('MerchantPersonalDetails');
});
server.post('/custentry',(req,res)=>{
  merchant.insertCustDetails(server.locals.id,req.body,function (err, result){ 
    if(err) return res.redirect('/MerchcustomerEntry');
    return  res.render('MerchcustomerEntry');
  }); 
});
server.post('/updateCustDetails',(req,res)=>{
  customer.updateCustPersonalDetails(server.locals.id,req.body,function (err, result){ 
    if(err) return res.redirect('/CustomerPersonalDetails');
    return  res.render('CustomerPersonalDetails');
  }); 
});
server.post('/updateMerchDetails',(req,res)=>{
  merchant.updateMerPersonalDetails(server.locals.id,req.body,function (err, result){ 
    if(err) return res.redirect('/MerchantPersonalDetails');
    return  res.render('MerchantPersonalDetails');
  }); 
});
server.post('/mercclear',(req,res)=>{
  return res.redirect('/MerchantPersonalDetails');
});
server.post('/clear',(req,res)=>{
  return res.redirect('/CustomerPersonalDetails');
});
server.get('/CustomerPersonalDetails',(req,res)=>{
  return  res.render('CustomerPersonalDetails');
});
server.get('/CustomerHome',(req,res)=>{
  customer.getCouponlist(server.locals.id,function (err, result){ 
    if(result.length==0) return res.redirect('/CustomerHome');
    server.locals.coupons=JSON.parse(JSON.stringify(result));
    console.log(server.locals.coupons);
    return  res.render('CustomerHome');
  }); 
});
server.get('/CustomerCoupons',(req,res)=>{
  customer.getUsedCouponlist(server.locals.id,function (err, result){ 
    if(err) 
    {
      return res.redirect('/CustomerCoupons');
  }else
    server.locals.usedcoupons=JSON.parse(JSON.stringify(result));
    return  res.render('CustomerCoupons');
  }); 
});
server.get('/CustomerRedeemPoints',(req,res)=>{
  customer.getReedemlist(server.locals.id,function (err, result){ 
    if(err) 
    {
      return res.redirect('/CustomerRedeemPoints');
    }
    server.locals.redeemcoupons=JSON.parse(JSON.stringify(result));
    console.log(server.locals.redeemcoupons[0].totalpoints);
    server.locals.points=server.locals.redeemcoupons[0].totalpoints;
    return  res.render('CustomerRedeemPoints');
  }); 
});
server.use('/api',apiRouter);

server.listen(configval.port,()=>{
 console.log('express listening to port', configval.port);
});