console.log('temp.js');
const sub=document.getElementById('sub');
sub.addEventListener('click',function(e)
{
    console.log('iside funct');
});
