class Customer
{
  Customer()
  {
    
  }
  getSqlConnection()
  {
    var mysql=require('mysql');
    var conn=mysql.createConnection({
      host     : '127.0.0.1', //mysql database host name
      user     : 'root', //mysql database user name
      password : 'password', //mysql database password
      database : 'test' //mysql database name
    });
    conn.connect(function(err) {
      if (err) return err;
      console.log('You are now connected...');
    });
    return conn;
  }
  getCouponlist(userid,callback) { 
    
    var conn=this.getSqlConnection();   
    conn.query('select xc.store_name,xc.coupon_codename,xc.coupon_discount,DATE_FORMAT(xc.coupon_validitydate,"%Y-%m-%d") coupon_validitydate from xx_merchant_coupon xc where xc.coupon_status="A" and not exists (select coupon_id from xx_customer_usedcoupons cs where customer_id="'+userid+'" and cs.coupon_id=xc.coupon_id)',
      function (err, rows) {
        if(err) console.log(err);
        else
        {
          console.log(rows);
          callback(err, rows);
        } 
      }
    ); 
      
  }
  getUsedCouponlist(userid,callback) { 
    console.log('getUsedCouponlist'+userid);
    if(userid)
    {
      var conn=this.getSqlConnection();   
      conn.query('select cs.store_name,mc.coupon_codename,DATE_FORMAT(cs.added_date,"%Y-%m-%d") coupon_useddate from xx_customer_usedcoupons cs, xx_merchant_coupon mc where cs.coupon_id=mc.coupon_id and cs.merchant_id=mc.user_id and cs.customer_id="'+userid+'"',
        function (err, rows) {
          if(err) console.log(err);
          else
          {
            console.log(rows);
            callback(err, rows);
          } 
        }
      ); 
    } else{
      callback('No records',[]);
    }
  }
  updateCustPersonalDetails(userid,personaldetails,callback) { 
    console.log('getUsedCouponlist'+userid);
    if(userid)
    {
      var conn=this.getSqlConnection();   
      conn.query('UPDATE xx_users set user_fname="'+personaldetails.Fname+'" , user_lname="'+personaldetails.Lname+'",user_mnumber="'+personaldetails.Mnumber+'",user_emailid="'+personaldetails.EmailId+'" where user_id="'+userid+'"',function (err, rows) {
        if(err) console.log(err);
        else
        {
          console.log(rows);
          callback(err, rows);
        } 
      }
      ); 
    } else{
      callback('No records',[]);
    }
  }
  getReedemlist(userid,callback) { 
    console.log('getUsedCouponlist'+userid);
    if(userid)
    {
      var conn=this.getSqlConnection();   
      conn.query('select custref_name,custref_discount,custref_discount as custref_points,DATE_FORMAT(custref_validitydate,"%Y-%m-%d") validity_date,(select coalesce(sum(custref_discount),0) from xx_cust_referral where custref_status="A" and posted_status="Y" and customer_id="'+userid+'" ) as totalpoints from xx_cust_referral where custref_status="A" and posted_status="N"and customer_id="'+userid+'"',
        function (err, rows) {
          if(err) console.log(err);
          else
          {
            console.log(rows);
            callback(err, rows);
          } 
        }
      ); 
    } else{
      callback('No records',[]);
    }
  }
}
module.exports=Customer;