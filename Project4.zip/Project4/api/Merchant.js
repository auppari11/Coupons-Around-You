class Merchant
{
  Merchant()
  {
    
  }
  getSqlConnection()
  {
    var mysql=require('mysql');
    var conn=mysql.createConnection({
      host     : '127.0.0.1', //mysql database host name
      user     : 'root', //mysql database user name
      password : 'password', //mysql database password
      database : 'test' //mysql database name
    });
    conn.connect(function(err) {
      if (err) return err;
      console.log('You are now connected...');
    });
    return conn;
  }
  insertcoupon(id,storename,coupondtls)
  {
    var cpstatus='A';
    var mainpg=require('./api/Main');
    var mp=new mainpg();
    var conn=mp.getSqlConnection();
    conn.query('INSERT INTO xx_merchant_coupon(coupon_id,user_id,store_name,coupon_codename,coupon_discount,coupon_validitydate,coupon_count,coupon_status) VALUES(NULL,"'+id+'","'+storename+'","'+coupondtls.codename+'","'+coupondtls.dsctpercnt+'","'+coupondtls.cpvdate+'","'+coupondtls.cpcount+'","'+cpstatus+'")', function (error, results, fields) {
      if (error) return error;
      console.log('id here '+results.id);
    });
    return true;
  }
  updateMerPersonalDetails(userid,personaldetails,callback) { 
    console.log('getUsedCouponlist'+userid);
    if(userid)
    {
      var conn=this.getSqlConnection();   
      conn.query('UPDATE xx_users set user_fname="'+personaldetails.Fname+'" ,merchant_sname="'+personaldetails.storename+'", user_lname="'+personaldetails.Lname+'",user_mnumber="'+personaldetails.Mnumber+'",user_emailid="'+personaldetails.EmailId+'" where user_id="'+userid+'"',function (err, rows) {
        if(err) console.log(err);
        else
        {
          console.log(rows);
          callback(err, rows);
        } 
      }
      ); 
    } else{
      callback('No records',[]);
    }
  }
  getMerchantCoupon(userid,callback) { 
    console.log(userid);
    if(userid)
    {
      var conn=this.getSqlConnection();   
      conn.query('select coupon_codename,coupon_discount,DATE_FORMAT(coupon_validitydate,"%Y-%m-%d") coupon_validitydate from xx_merchant_coupon where user_id="'+userid+'" and coupon_status="A"',
        function (err, rows) {
          if(err) console.log(err);
          else
            {
            console.log(rows);
            callback(err, rows);
            } 
        }
      ); 
    } else{
      callback('No records',[]);
    }  
  }
  insertCustDetails(userid,req) 
  {
    var conn=this.getSqlConnection();  
    conn.query('call insertdetails("'+userid+'","'+req.Fname+'","'+req.Mnumber+'","'+req.EmailId+'","'+req.Couponcode+'")', function (error, results, fields) {
      if (error) return error;
      console.log('You are now connected...');
    });
    return true;
  }
}
module.exports=Merchant;