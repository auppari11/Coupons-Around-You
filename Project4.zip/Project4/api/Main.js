class MainForm
{
  MainForm()
  {
    console.log('inside Mainform');   
  }
  getSqlConnection()
  {
    var mysql=require('mysql');
    var conn=mysql.createConnection({
      host     : '127.0.0.1', //mysql database host name
      user     : 'root', //mysql database user name
      password : 'password', //mysql database password
      database : 'test' //mysql database name
    });
    conn.connect(function(err) {
      if (err) return err;
      console.log('You are now connected...');
    });
    return conn;
  }
  getId(username,pwd,callback) { 
    console.log(username+' '+pwd);
    if(username && pwd)
    {
      var conn=this.getSqlConnection();   
      conn.query('select user_id,user_type,merchant_sname from xx_users where user_emailid="'+username+'" and user_pwd="'+pwd+'"',
        function (err, rows) {
          if(err) console.log(err);
          else
            callback(err, rows); 
        }
      ); 
    } else{
      callback('No records',[]);
    }  
  }
  insertRegDetails(Regdetails) 
  {
    console.log('inside regdetails');
    // console.log(Regdetails1);
    // var Regdetails=JSON.parse(JSON.stringify(Regdetails1.body));
    console.log(Regdetails.merchantnumber);
    var conn=this.getSqlConnection();  
    var usertype='M';
    if(Regdetails.merchantnumber=='')
    {
      console.log('inside');
      usertype='C';
    }
    conn.query('INSERT INTO XX_USERS (user_id,user_type,user_fname,user_lname,user_mnumber,merchant_idnumber,merchant_sname,user_emailid,user_pwd) VALUES(NULL,"'+usertype+'","'+Regdetails.Fname+'","'+Regdetails.Lname+'","'+Regdetails.Mnumber+'","'+Regdetails.merchantnumber+'","'+Regdetails.storename+'","'+Regdetails.EmailId+'","'+Regdetails.pwd+'")', function (error, results, fields) {
      if (error) return error;
      console.log('You are now connected...');
    });
    return true;
  }
}

module.exports=MainForm;