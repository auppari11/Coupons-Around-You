const env=process.env;

const port= env.PORT||8080;

module.exports={port};